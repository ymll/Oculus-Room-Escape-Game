#include "LeapMotionPrivatePCH.h"
#include "LeapBaseObject.h"

ULeapBaseObject::ULeapBaseObject(const FObjectInitializer &init) : UObject(init)
{
}